package com.example.apchanda.asynctask;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by apchanda on 11/20/2015.
 */
public class ListAdapter extends BaseAdapter {

    ArrayList<WeatherInfo> weatherInfoList=new ArrayList<>();
    Activity mActivity;
   public ListAdapter(Activity activity,ArrayList<WeatherInfo> weatherInfo){
       this.weatherInfoList = weatherInfo;
        this.mActivity = activity;
    }

    @Override
    public int getCount() {
        return weatherInfoList.size();
    }

    @Override
    public Object getItem(int i) {
        return weatherInfoList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        if(view==null){
            view = mActivity.getLayoutInflater().inflate(R.layout.listview_row_layout,null);
        }
        TextView date = (TextView)view.findViewById(R.id.date);
        TextView min = (TextView)view.findViewById(R.id.min);
        TextView max = (TextView)view.findViewById(R.id.max);
        TextView forecast = (TextView)view.findViewById(R.id.forecast);

        WeatherInfo weatherInfo = weatherInfoList.get(i);
        date.setText(weatherInfo.getDate().toString());
        min.setText(weatherInfo.getMinTemp()+"");
        max.setText(weatherInfo.getMaxTemp()+"");
        forecast.setText(weatherInfo.getForecast());

        return view;
    }
}
