package com.example.apchanda.asynctask;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends Activity {

    ProgressDialog pd;
    private static final String API_URL_FIRST_PART = "http://api.openweathermap.org/data/2.5/forecast/daily?q=";
    private static final String API_URL_LAST_PART = "&mode=json&units=metric&cnt=10&APPID=d11ec4866a0f102966b0d983484bbaeb";
    ArrayList<WeatherInfo> weatherList = new ArrayList<>();
    ListView weatherListView;
    ListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        weatherListView = (ListView)findViewById(R.id.weatherList);
        adapter = new ListAdapter(this,weatherList);
        weatherListView.setAdapter(adapter);
        pd = new ProgressDialog(this);
        pd.setMessage("Fetching data");

        FetchWeatherInformation task= new FetchWeatherInformation();
        task.execute("Tempe");
    }

    private class FetchWeatherInformation extends AsyncTask<String, Void, String> {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd.show();
        }

        @Override
        protected String doInBackground(String[] data) {
            InputStream is = null;
            String responseJSON = null;
            int len = 1500;

            try {
                URL url = new URL(API_URL_FIRST_PART + data[0] + API_URL_LAST_PART);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000 /* milliseconds */);
                conn.setConnectTimeout(15000 /* milliseconds */);
                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                // Starts the query
                conn.connect();

                is = conn.getInputStream();

                // Convert the InputStream into a string

                char[] buffer = new char[len];
                final StringBuilder out = new StringBuilder();
                try (Reader in = new InputStreamReader(is, "UTF-8")) {
                    for (; ; ) {
                        int rsz = in.read(buffer, 0, buffer.length);
                        if (rsz < 0)
                            break;
                        out.append(buffer, 0, rsz);
                    }
                } catch (UnsupportedEncodingException ex) {
                    ex.printStackTrace();
                }
                responseJSON = new String(out);

                // Makes sure that the InputStream is closed after the app is
                // finished using it.
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (is != null) {
                    try {
                        is.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return responseJSON;
        }

        @Override
        protected void onPostExecute(String response) {
            super.onPostExecute(response);
            if(pd.isShowing())
                pd.dismiss();
            if(response!=null){
                System.out.println(response);
                parseResponseIntoList(response);
            }
        }
    }
    private ArrayList<WeatherInfo> parseResponseIntoList(String responseJSON) {

        try {
            JSONObject obj = new JSONObject(responseJSON);
            JSONArray arr = obj.getJSONArray("list");
            for (int i = 0; i < arr.length(); i++)
            {
                WeatherInfo info = new WeatherInfo();
                info.setDate(new Date(arr.getJSONObject(i).getLong("dt")*1000));
                JSONObject tempObj = arr.getJSONObject(i).getJSONObject("temp");
                info.setMaxTemp(tempObj.getDouble("max"));
                info.setMinTemp(tempObj.getDouble("min"));

                JSONArray weatherObj = arr.getJSONObject(i).getJSONArray("weather");
                info.setForecast(weatherObj.getJSONObject(0).getString("description"));

                weatherList.add(info);
            }

            adapter.notifyDataSetChanged();


        } catch (JSONException e) {
            e.printStackTrace();
        }

        return weatherList;
    }
}
